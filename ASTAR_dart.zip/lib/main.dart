import 'dart:math';

// Global olarak erişilebilir grid
List<List<String>> grid = [];

void main() {
  final random = Random();

  // 10x10 rastgele engeller içeren grid oluştur
  for (int i = 0; i < 10; i++) {
    List<String> row = [];

    for (int j = 0; j < 10; j++) {
      if (random.nextInt(10) <= 1) {
        row.add("|"); // Engel
      } else {
        row.add("."); // Boş alan
      }
    }
    grid.add(row);
  }

  // Başlangıç ve bitiş noktaları
  grid[0][0] = "b"; // Başlangıç noktası
  grid[9][9] = "X"; // Hedef noktası

  for (var row in grid) {
    print(row.join());
  }

  // A* algoritmasını başlat
  Node start = Node(0, 0, null);
  Node goal = Node(9, 9, null);
  aStar(start, goal, grid);
}

// Node sınıfı
class Node {
  int x, y;
  int g; // g değeri
  int f; // f değeri (g + h)
  Node? parent;

  Node(this.x, this.y, this.parent) :
    g = parent != null ? parent.g + 1 : 0, // g değeri ebeveynden türetilir
    f = 0; // Başlangıçta f değeri 0

  // Expand fonksiyonu
  List<Node> expand() {
    List<Node> children = [];
    List<List<int>> moves = [
      [-1, 0], [1, 0],  // Yukarı ve Aşağı
      [0, -1], [0, 1]   // Sol ve Sağ
    ];

    for (var move in moves) {
      int newX = x + move[0];
      int newY = y + move[1];

      // Grid sınırlarını ve engelleri kontrol et
      if (newX >= 0 && newX < grid.length &&
          newY >= 0 && newY < grid[0].length &&
          grid[newX][newY] != "|") {  // Engel değilse ekle
        children.add(Node(newX, newY, this));
      }
    }
    return children;
  }
}

// A* algoritması
void aStar(Node first, Node last, List<List<String>> grid) {
  Node current = first;
  List<Node> closed = [];
  List<Node> open = [current];
  
  // Çözüm labirenti için kopya grid oluşturuluyor.
  List<List<String>> copygrid = [];
  for (int i = 0; i < 10; i++) {
    List<String> row = [];

    for (int j = 0; j < 10; j++) {
      if (grid[i][j] == "|") {
        row.add("|"); // Engel
      } else if (grid[i][j] == ".") {
        row.add("."); // Boş alan
      } else {
        row.add(grid[i][j]); // Başlangıç 'b' ve hedef 'X'
      }
    }
    copygrid.add(row);
  }

  while (open.isNotEmpty) {
    // open listesinden en küçük f değerine sahip node'u çıkar
    open.sort((a, b) => (a.f).compareTo(b.f));
    current = open.removeAt(0);
    closed.add(current);

    // Eğer hedefe ulaşıldıysa çık
    if (current.x == last.x && current.y == last.y) {
      print("\nHedefe ulaşıldı!");
      // Çözümü işaretle
      while (current.parent != null) {
        copygrid[current.x][current.y] = "*"; // Yolu işaretle
        current = current.parent!;
      }
      // Sonuç gridini yazdır
      for (var row in copygrid) {
        print(row.join());
      }
      return;
    }

    // Expand metodunu çağır
    for (Node i in current.expand()) {
      if (!closed.any((node) => node.x == i.x && node.y == i.y)) {//kapalı listede olan düğümü bir daha genişletme
        // h değeri (Manhattan mesafesi)
        int h = (9 - i.x) + (9 - i.y);
        // g değeri (mesafe)
        int g = i.parent!.g + 1;
        // f değeri (g + h)
        int f = g + h;

        // f değerine göre open listesinde sıralama
        i.g = g;
        i.f = f;

        if (!open.any((node) => node.x == i.x && node.y == i.y)) {
          open.add(i);
        }
      }
    }
  }

  print("Çözüm bulunamadı!"); // random engeller olduğu için başlanıç veya amaç düğümünün etrafı sarılabilir
}
